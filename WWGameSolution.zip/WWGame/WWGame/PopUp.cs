﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WWGame
{
    public partial class PopUp : Form
    {
        public PopUp()
        {
            InitializeComponent();
            //prevents player from minimizing, maximizing, or closing window using control bar.
            ControlBox = false;
        }
        //Easily change the label text for popup
        public void textChanger(string text)
        {
            label1.Text = text;
        }
        // OK button, closes game
        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
