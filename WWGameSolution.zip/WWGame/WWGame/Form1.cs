﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WWGame
{
    public partial class Form1 : Form
    {
        WWController Game;
        List<Button> buttons2;
        int score;
        public Form1()
        {         
            InitializeComponent();
            Game = new WWController();
             buttons2 = new List<Button> { button2, button3, button4, button5, button6, button7, button8 };
            score = 0;
            
        }
        /*Start Wumpus world button. Creates a WWHandler on proper input, creates a popup explaining
         * the error in input if it fails
         */
        private void button1_Click(object sender, EventArgs e)
        {
            string input = textBox1.Text;
            if(Game.StartGame(input))
            {
                button1.Visible = false;
                button1.Enabled = false;
                label1.Visible = false;
                label2.Visible = false;
                textBox1.Visible = false;
                textBox1.Text = "";
                textBox1.Enabled = false;
                foreach(Button button in buttons2)
                {
                    button.Visible = true;
                    button.Enabled = true;
                }
                textBox2.Visible = true;
                addTextToBox("You have entered the Wumpus cave in search of gold. Find your way safely to the gold and back out.\n");
                addTextToBox("If you feel a breeze you are near a pit and if you notice a foul odor the wumpus is nearby. Good Luck\n");
                addTextToBox(Game.displayPercepts());
            }
            else
            {
                PopUp popUp = new PopUp();
                popUp.textChanger("You must enter Easy, Medium, or Hard");
                popUp.Show();
            }
            
        }
        //West
        private void button5_Click(object sender, EventArgs e)
        {
            addTextToBox(Game.takeInput("w"));
            addTextToBox(Game.displayPercepts());
            gameStateHandler(Game.gameStatus());
        }
        //North
        private void button3_Click(object sender, EventArgs e)
        {
            addTextToBox(Game.takeInput("n"));
            addTextToBox(Game.displayPercepts());
            gameStateHandler(Game.gameStatus());
        }
        //Fire
        private void button6_Click(object sender, EventArgs e)
        {
            addTextToBox(Game.takeInput("f"));
        }
        //East
        private void button4_Click(object sender, EventArgs e)
        {
            addTextToBox(Game.takeInput("e"));
            addTextToBox(Game.displayPercepts());
            gameStateHandler(Game.gameStatus());
        }
        //South
        private void button2_Click(object sender, EventArgs e)
        {
            addTextToBox(Game.takeInput("s"));
            addTextToBox(Game.displayPercepts());
            gameStateHandler(Game.gameStatus());
        }
        //Grab
        private void button7_Click(object sender, EventArgs e)
        {
            addTextToBox(Game.takeInput("g"));
            addTextToBox(Game.displayPercepts());
            gameStateHandler(Game.gameStatus());
        }
        //Climb
        private void button8_Click(object sender, EventArgs e)
        {
            addTextToBox(Game.takeInput("c"));
            addTextToBox(Game.displayPercepts());
            gameStateHandler(Game.gameStatus());
        }

        private void addTextToBox(string text)
        {
            textBox2.AppendText(text);
        }
        /* Handles how the Form progresses based off of the state of the game.
         * If the player gets a GAME OVER (state = 0) the score is reset to zero, the game is reset and a popup tells 
         * tells them they have lost, returning to the start screen.
         * 
         * If the player wins (state = 1) the score is added  to the forms score variable and the player
         * recieves a popup alerting them about winning. the form is reset to the start screen with the updated score.
         * 
         * if the player is still playing (state = 2) nothing happens, the Form keeps waitning for input and does so until another state is reached.
         */
        private void gameStateHandler(int state)
        {

            switch(state)
            {
                case 0:
                    PopUp popUp = new PopUp();
                    popUp.textChanger("You have died and lost all your gold. Press ok to continue");
                    popUp.Show();
                    button1.Visible = true;
                    button1.Enabled = true;
                    label1.Visible = true;
                    label2.Visible = true;
                    textBox1.Visible = true;
                    textBox1.Enabled = true;
                    foreach (Button button in buttons2)
                    {
                        button.Visible = false;
                        button.Enabled = false;
                    }
                    textBox2.Visible = false;
                    score = 0;
                    label3.Text = "score: " + score.ToString();
                    textBox2.ResetText();
                    break;
                case 1:
                    score += Game.getScore();
                    label3.Text = "score: " + score.ToString();
                    popUp = new PopUp();
                    popUp.textChanger("You Have the Gold and have escaped! Congratulations, you win!");
                    popUp.Show();
                    button1.Visible = true;
                    button1.Enabled = true;
                    label1.Visible = true;
                    label2.Visible = true;
                    textBox1.Visible = true;
                    textBox1.Enabled = true;
                    foreach (Button button in buttons2)
                    {
                        button.Visible = false;
                        button.Enabled = false;
                    }
                    textBox2.Visible = false;
                    textBox2.ResetText();
                    break;
                default:
                    break;

            }
        }
    }
}
