﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WWGame
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
    /* WWController acts as a Controller which interfaces between the model(running gameworld)
     * and the view (the Form).
     * 
     * The Controller has a few variables it tracks, primarily because they effect how the controller operates 
     * and what message the controller returns.
     * 
     * The controller is first initilized with the initilizer, but must then be initilized again before each game
     * using StartGame(difficulty). This generates the Model that will be used by all other functions.
     * 
     * takeInput(input) converts input in the form of a string into an one of the games controls and outputs the appropriate result.
     * This functions should maintain its ability to parse input for purposes of unit testing.
     * 
     * displayPercepts() returns the seses of the player based off of their location in the world. This function also returns the gameover state 
     * Which is updated in the controller.
     * 
     * gameStatus() returns a game state (0,1, or 2) based off of the game state varibles (gameOver and wonGame). This should be used to determine 
     * if the view should continue running the game screen or switch back to the start screen. 
     * 
     * getScore() returns the score of the current Game. This score is calculated based off the difficulty and the number of steps taken.
     */
    class WWController
    {
        WWSim Simulation;
        WWModel gameWorld;
        bool gameOver;
        bool wonGame;
        bool firingArrow;
        public WWController()
        {
            Simulation = new WWSim();
            gameOver = false;
            firingArrow = false;
            wonGame = false;
        }
        public bool isGameOver()
        {
            return gameOver;
        }
        public bool StartGame(string difficulty)
        {
            gameWorld = Simulation.enterWumpusWorld( difficulty);
            gameOver = false;
            firingArrow = false;
            wonGame = false;
            if (gameWorld == null)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        public string takeInput(string input)
        { 
            if(firingArrow)
            {
                firingArrow = false;
                return gameWorld.fireArrowInput(input);
            }
            else
            {
                string returnValue =  gameWorld.takeInput(input);
                if(returnValue.Contains("you win"))
                {
                    wonGame = true;
                }
                else if(returnValue.Contains("Would you like to fire"))
                {
                    firingArrow = true;
                }
                return returnValue;
            }
            
        }
        public string displayPercepts()
        {
            string returnValue = gameWorld.displayPercepts();
            if(returnValue.Contains("GAME OVER"))
            {
                gameOver = true;
            }

            return returnValue;
        }
        public int gameStatus()
        {
            if(gameOver)
            {
                return 0;
            }
            else if(wonGame)
            {
                return 1;
            }
            else
            {
                return 2;
            }
        }
        public int getScore()
        {
            return gameWorld.getScore();
        }
    }
    class WWSim
    {
        /* This program runs a version of Wumpus World  coded by Christian Boyd
         * In Wumpus world you play as an explorer entering a pitch black cave to find riches.
         * You can move North (n), South (s), East (e), West (w), Fire the arrow (f), Grab gold (g), or Climb out (c) 
         * While in the cave you have can hardly see anything, but can smell, hear, and feel the environment around you
         * which alerts you to what might be near you.
         * 
         * If "you feel a breeze" you are adjacent to a pit.
         * If "you bumped into something" you have run into a wall.
         * If "notice something glittering" you have found a pile of gold.
         * But beware, if "you smell a foul stench" you are near the Wumpus, a fearsome beast that will kill you if you touch it.
         * If you think you know where the Wumpus is you can fire  an arrow, causing the Wumpus to scream if you kill it.
         * Once you find the gold find your way back to the entrance and climb out.
         */

        //initializes game and returns the model. Makes use of WWBoard generator to do so.
        public WWModel enterWumpusWorld( string input)
        {
            //intro sequence
            Console.WriteLine("Welcome to Wumpus world!");
            // instructions
            Console.WriteLine("You can move North (n), South (s), East (e), West (w), Fire the arrow (f), Grab gold (g), or Climb out (c) \n" +
                "if you forget the controls type help. How difficult do you want your game to be?\n Easy, Medium, or Hard?\n Please enter your choice");
            bool keepRunning = true;
            int difficulty = 0;
            //Generate the board
            Byte[,] board = new Byte[1, 1];
            while (keepRunning)
            {
                WWBoardCreator creation = new WWBoardCreator();
                if (input.ToLower().Equals("easy"))
                {
                    difficulty = 1;
                    board = creation.generateWorld(difficulty);
                    keepRunning = false;
                }
                else if (input.ToLower().Equals("medium"))
                {
                    difficulty = 2;
                    board = creation.generateWorld(2);
                    keepRunning = false;
                }
                else if (input.ToLower().Equals("hard"))
                {
                    difficulty = 3;
                    board = creation.generateWorld(3);
                    keepRunning = false;
                }
                //Popup error?
                else
                {

                    return null;
                }
            }
            //Play the game
            WWModel game = new WWModel();
            game.startGame(board, difficulty);
            return game;

        }
    }

    /*Creates a board of varied size and hole frequency based on inputs. Once board is created it is tested to see if it is completable. 
     * internal functions are helper functions that aid in this task. Searching for a path is a simple breadth first search algorithm.
     */ 
    class WWBoardCreator
    {
        // This table is for the purposes of readability and maintainability. 
        byte empty = 0; byte hole = 1; byte breeze = 2; byte wumpus = 3; byte stench = 4; byte glitter = 5; byte breezeStench = 6;
        byte breezeGlitter = 7; byte stenchGlitter = 8, breezeStenchGlitter = 9; byte escape = 10; byte wumpusGlitter = 11; byte wumpusBreeze = 12;
        byte wumpusBreezeGlitter = 13;
        public Byte[,] generateWorld(int difficulty)
        {
            bool notWinnable = true;
            Byte[,] world;
            //empty = 0; hole = 1; breeze = 2; wumpus = 3; stench = 4; glitter = 5; breezeStench = 6; breezeGlitter = 7; 
            //stenchGlitter = 8, breezeStenchGlitter = 9; escape = 10; wumpusGlitter = 11; wumpusBreeze = 12; wumpusBreezeGlitter = 13;
            int widthOrHeight = 0;
            float holepercentage = 0;
            Random rand = new Random();
            switch (difficulty)
            {
                case 1:
                    holepercentage = 0.2f;
                    world = new Byte[4, 4];
                    widthOrHeight = 4;
                    break;
                case 2:
                    holepercentage = 0.3f;
                    world = new Byte[6, 6];
                    widthOrHeight = 6;
                    break;
                case 3:
                    holepercentage = 0.35f;
                    world = new Byte[8, 8];
                    widthOrHeight = 8;
                    break;
                default:
                    holepercentage = 0.2f;
                    world = new Byte[4, 4];
                    widthOrHeight = 4;
                    break;
            }
            while (notWinnable)
            {
                // build world
                for (int i = 0; i < widthOrHeight; i++)
                {
                    for (int j = 0; j < widthOrHeight; j++)
                    {
                        world[i, j] = empty;
                    }
                }
                world[0, 0] = escape;
                // place Wumpus
                int x = rand.Next(1, widthOrHeight);
                int y = rand.Next(1, widthOrHeight);
                world[y, x] = wumpus;
                emitPercept(stench, y, x, widthOrHeight, ref world);

                // place gold
                x = rand.Next(1, widthOrHeight);
                y = rand.Next(1, widthOrHeight);
                world[y, x] = placeLabels(glitter, world[y, x]);
                // place pits
                for (int i = 0; i < widthOrHeight; i++)
                {
                    for (int j = 0; j < widthOrHeight; j++)
                    {
                        if (rand.NextDouble() <= holepercentage)
                        {
                            world[i, j] = placeLabels(hole, world[i, j]);
                            if (world[i, j] == hole)
                            {
                                emitPercept(breeze, i, j, widthOrHeight, ref world);
                            }
                        }
                    }
                }
                //Verify it is completable to ensure fair game
                bool routeNotFound = true;
                List<Tuple<int, int>> unvisited = new List<Tuple<int, int>>();
                List<Tuple<int, int>> visited = new List<Tuple<int, int>>();
                unvisited.Add(Tuple.Create<int, int>(0, 0));

                Tuple<int, int> currentPoint;
                while (routeNotFound && unvisited.Count > 0)
                {
                    currentPoint = unvisited[0];
                    visited.Add(currentPoint);
                    unvisited.RemoveAt(0);
                    Tuple<int, int> nextPoint;
                    if (SafetyTest(currentPoint.Item2 - 1, currentPoint.Item1, widthOrHeight, ref world))
                    {
                        nextPoint = Tuple.Create<int, int>(currentPoint.Item2 - 1, currentPoint.Item1);
                        routeNotFound = spotChecker(nextPoint, ref unvisited, ref visited, ref world);
                    }
                    if (SafetyTest(currentPoint.Item2 + 1, currentPoint.Item1, widthOrHeight, ref world))
                    {
                        nextPoint = Tuple.Create<int, int>(currentPoint.Item2 + 1, currentPoint.Item1);
                        routeNotFound = spotChecker(nextPoint, ref unvisited, ref visited, ref world);
                    }
                    if (SafetyTest(currentPoint.Item2, currentPoint.Item1 - 1, widthOrHeight, ref world))
                    {
                        nextPoint = Tuple.Create<int, int>(currentPoint.Item2, currentPoint.Item1 - 1);
                        routeNotFound = spotChecker(nextPoint, ref unvisited, ref visited, ref world);
                    }
                    if (SafetyTest(currentPoint.Item2, currentPoint.Item1 + 1, widthOrHeight, ref world))
                    {
                        nextPoint = Tuple.Create<int, int>(currentPoint.Item2, currentPoint.Item1 + 1);
                        routeNotFound = spotChecker(nextPoint, ref unvisited, ref visited, ref world);
                    }
                }
                // Uncomment to see boards that are created
                /*
                for (int i = widthOrHeight-1; i >= 0; i--)
                {
                    for (int j = 0; j < widthOrHeight; j++)
                    {
                        Console.Write(world[i, j] + " ");
                    }
                    Console.Write("\n");
                }*/
                if (!routeNotFound)
                {
                    notWinnable = false;
                }
            }
            return world;
        }
        //tries to place the percept into the world within the boundary of the world
        // Used for pits and Wumpus.
        void emitPercept(byte percept, int originy, int originx, int heightOrWidth, ref Byte[,] world)
        {
            if (originy == 0)
            {
                if (originx == 0)
                {
                    world[originy + 1, originx] = placeLabels(percept, world[originy + 1, originx]);
                    world[originy, originx + 1] = placeLabels(percept, world[originy, originx + 1]);
                }
                else if (originx == heightOrWidth - 1)
                {
                    world[originy, originx - 1] = placeLabels(percept, world[originy, originx - 1]);
                    world[originy + 1, originx] = placeLabels(percept, world[originy + 1, originx]);
                }
                else
                {
                    world[originy, originx - 1] = placeLabels(percept, world[originy, originx - 1]);
                    world[originy + 1, originx] = placeLabels(percept, world[originy + 1, originx]);
                    world[originy, originx + 1] = placeLabels(percept, world[originy, originx + 1]);
                }
            }
            else if (originy == heightOrWidth - 1)
            {
                if (originx == 0)
                {
                    world[originy - 1, originx] = placeLabels(percept, world[originy - 1, originx]);
                    world[originy, originx + 1] = placeLabels(percept, world[originy, originx + 1]);
                }
                else if (originx == heightOrWidth - 1)
                {
                    world[originy - 1, originx] = placeLabels(percept, world[originy - 1, originx]);
                    world[originy, originx - 1] = placeLabels(percept, world[originy, originx - 1]);
                }
                else
                {
                    world[originy - 1, originx] = placeLabels(percept, world[originy - 1, originx]);
                    world[originy, originx - 1] = placeLabels(percept, world[originy, originx - 1]);
                    world[originy, originx + 1] = placeLabels(percept, world[originy, originx + 1]);
                }
            }
            else
            {
                if (originx == 0)
                {
                    world[originy - 1, originx] = placeLabels(percept, world[originy - 1, originx]);
                    world[originy + 1, originx] = placeLabels(percept, world[originy + 1, originx]);
                    world[originy, originx + 1] = placeLabels(percept, world[originy, originx + 1]);
                }
                else if (originx == heightOrWidth - 1)
                {
                    world[originy - 1, originx] = placeLabels(percept, world[originy - 1, originx]);
                    world[originy, originx - 1] = placeLabels(percept, world[originy, originx - 1]);
                    world[originy + 1, originx] = placeLabels(percept, world[originy + 1, originx]);
                }
                else
                {
                    world[originy - 1, originx] = placeLabels(percept, world[originy - 1, originx]);
                    world[originy, originx - 1] = placeLabels(percept, world[originy, originx - 1]);
                    world[originy + 1, originx] = placeLabels(percept, world[originy + 1, originx]);
                    world[originy, originx + 1] = placeLabels(percept, world[originy, originx + 1]);
                }
            }
        }
        //checks how newLabel interacts with oldLabel and takes appropriate action.
        byte placeLabels(byte newLabel, byte oldLabel)
        {
            //empty = 0; hole = 1; breeze = 2; wumpus = 3; stench = 4; glitter = 5; breezeStench = 6; breezeGlitter = 7; 
            //stenchGlitter = 8, breezeStenchGlitter = 9; escape = 10; wumpusGlitter = 11; wumpusBreeze = 12; wumpusBreezeGlitter = 13;
            byte returnvalue = newLabel;
            switch (oldLabel)
            {
                case 1:
                    returnvalue = oldLabel;
                    break;
                case 2:
                    switch (newLabel)
                    {
                        case 1:
                            returnvalue = newLabel;
                            break;
                        case 3:
                            returnvalue = wumpusBreeze;
                            break;
                        case 4:
                            returnvalue = breezeStench;
                            break;
                        case 5:
                            returnvalue = breezeGlitter;
                            break;
                        default:
                            break;
                    }
                    break;
                case 3:
                    switch (newLabel)
                    {
                        case 1:
                            returnvalue = oldLabel;
                            break;
                        case 2:
                            returnvalue = wumpusBreeze;
                            break;

                        case 5:
                            returnvalue = breezeGlitter;
                            break;

                        default:
                            break;
                    }
                    break;
                case 4:
                    switch (newLabel)
                    {
                        case 1:
                            returnvalue = newLabel;
                            break;
                        case 2:
                            returnvalue = breezeStench;
                            break;
                        case 5:
                            returnvalue = stenchGlitter;
                            break;
                        default:
                            break;
                    }
                    break;
                case 5:
                    switch (newLabel)
                    {
                        case 1:
                            returnvalue = oldLabel;
                            break;
                        case 2:
                            returnvalue = breezeGlitter;
                            break;
                        case 3:
                            returnvalue = wumpusGlitter;
                            break;
                        case 4:
                            returnvalue = stenchGlitter;
                            break;
                        default:
                            break;
                    }
                    break;
                case 6:
                    switch (newLabel)
                    {
                        case 1:
                            returnvalue = newLabel;
                            break;
                        case 5:
                            returnvalue = breezeStenchGlitter;
                            break;
                        default:
                            break;
                    }
                    break;
                case 7:
                    switch (newLabel)
                    {
                        case 1:
                            returnvalue = oldLabel;
                            break;
                        case 3:
                            returnvalue = wumpusBreezeGlitter;
                            break;
                        case 4:
                            returnvalue = breezeStenchGlitter;
                            break;
                        default:
                            break;
                    }
                    break;
                case 8:
                    switch (newLabel)
                    {
                        case 1:
                            returnvalue = oldLabel;
                            break;
                        case 2:
                            returnvalue = breezeStenchGlitter;
                            break;
                        default:
                            break;
                    }
                    break;
                case 9:
                    returnvalue = oldLabel;
                    break;
                case 10:
                    returnvalue = oldLabel;
                    break;
                case 11:
                    switch (newLabel)
                    {
                        case 1:
                            returnvalue = oldLabel;
                            break;
                        case 5:
                            returnvalue = wumpusBreezeGlitter;
                            break;
                        default:
                            break;
                    }
                    break;
                default:
                    break;
            }
            return returnvalue;
        }
        //checks if the passed x and y is a valid position and then checks if the position is a hole.
        //if position is invalid or location is a hole returns false representing a nonsafe path.
        bool SafetyTest(int y, int x, int heightOrWidth, ref Byte[,] world)
        {
            if (x >= 0 && x < heightOrWidth && y >= 0 && y < heightOrWidth)
            {
                if (world[y, x] == hole)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            return false;
        }
        //Checks if the space has gold.
        bool CheckForGold(byte labelOfSpace)
        {
            if (labelOfSpace == glitter || labelOfSpace == breezeGlitter || labelOfSpace == breezeStenchGlitter || labelOfSpace == stenchGlitter
                || labelOfSpace == wumpusBreezeGlitter || labelOfSpace == wumpusGlitter)
            {
                return true;
            }
            else { return false; }
        }
        //checks if current position has gold and if not plces unvisited spaces in unvisited list
        // in C#7.2 or greater ref on visited can be replaced with in an will be a read only reference.
        bool spotChecker(Tuple<int, int> nextPoint, ref List<Tuple<int, int>> unvisited, ref List<Tuple<int, int>> visited, ref Byte[,] world)
        {
            if (CheckForGold(world[nextPoint.Item2, nextPoint.Item1]))
            {
                return false;
            }
            else
            {

                if (!visited.Contains(nextPoint))
                {
                    unvisited.Add(nextPoint);
                }
            }
            return true;
        }
    }
    /*Represents the world and location of player.
     * 
     * startGame(board, difficulty) sets up the world.
     * 
     * displayPercepts() returns the senses of the player
     * 
     * takeInput() changes the world model based on player input
     * 
     * fireArrowInput() is special input path for when the player isa firing the arrow.
     * 
     * getScore() returns the score value of the current model
     */ 
    class WWModel
    {
        Byte[,] world; bool haveArrow; bool wumpusKilled; bool hasGold; int steps; Tuple<int, int> position;
        int maxXY; int score;
        public void startGame(Byte[,] board, int difficulty)
        {
            steps = 0;
            world = board;
            position = Tuple.Create<int, int>(0, 0);
            switch (difficulty)
            {
                case 1:
                    score = 1000;
                    maxXY = 4;
                    break;
                case 2:
                    score = 2000;
                    maxXY = 6;
                    break;
                case 3:
                    score = 3000;
                    maxXY = 8;
                    break;
                default:
                    score = 1000;
                    maxXY = 4;
                    break;
            }
            wumpusKilled = false;
            haveArrow = true;
            hasGold = false;
        }
        public string displayPercepts()
        {
            //empty = 0; hole = 1; breeze = 2; wumpus = 3; stench = 4; glitter = 5; breezeStench = 6; breezeGlitter = 7; 
            //stenchGlitter = 8, breezeStenchGlitter = 9; escape = 10; wumpusGlitter = 11; wumpusBreeze = 12; wumpusBreezeGlitter = 13;
            switch (world[position.Item1, position.Item2])
            {
                case 1:
                    return "You have fallen into a pit and died GAME OVER\n";
                    ;
                case 2:
                    return "You feel a breeze wash over you.\n";
                    ;
                case 3:
                    return "You have been eaten by the Wumpus. GAME OVER\n";
                    ;
                case 4:
                    return "You smell a foul stench.\n";
                    ;
                case 5:
                    return "You notice something glittering at your feet.\n";
                    ;
                case 6:
                    return "You smell a foul stench which is slightly lessened by the breeze blowing by.\n";
                    ;
                case 7:
                    return "You notice something glittering at your feet and a refreshing breeze is blowing by.\n";
                    ;
                case 8:
                    return "You notice something glittering at your feet and a foul stench ruins your excitement.\n";
                    ;
                case 9:
                    return "You notice something glittering at your feet and a foul stench ruins your excitement, but thankfully a breeze lessens the odor.\n";
                    ;
                case 10:
                    string returnValue = "You are where you started, here hangs a rope you can climb out with\n";
                    if (world[0, 1] == 1 || world[1, 0] == 1)
                    {
                        returnValue = returnValue + "You feel a breeze wash over you.\n";
                    }
                    if (world[0, 1] == 3 || world[1, 0] == 3)
                    {
                        returnValue = returnValue + "You smell a foul stench.\n";
                    }
                    return returnValue;
                    ;
                case 11:
                    return "You have been eaten by the Wumpus. GAME OVER\n";
                    ;
                case 12:
                    return "You have been eaten by the Wumpus. GAME OVER\n";
                    ;
                case 13:
                    return "You have been eaten by the Wumpus. GAME OVER\n";
                    ;
                default:
                    return "You notice nothing of interest\n";
                    ;
            }
        }

        public string takeInput(string input)
        {
            if (input.ToLower().Equals("n"))
            {
                if (position.Item1 + 1 < maxXY)
                {
                    steps++;
                    position = Tuple.Create<int, int>(position.Item1 + 1, position.Item2);
                    return "You move North\n";
                }
                else { return "You bump into the wall\n"; }
            }
            else if (input.ToLower().Equals("e"))
            {
                if (position.Item2 + 1 <maxXY )
                {
                    steps++;
                    position = Tuple.Create<int, int>(position.Item1, position.Item2 + 1);
                    return "You move East\n";
                }
                else { return "You bump into the wall\n"; }
            }
            else if (input.ToLower().Equals("s"))
            {
                if (position.Item1 - 1 >= 0)
                {
                    steps++;
                    position = Tuple.Create<int, int>(position.Item1 - 1, position.Item2);
                    return "You move South\n";
                }
                else { return "You bump into the wall\n"; }
            }
            else if (input.ToLower().Equals("w"))
            {
                if (position.Item2 - 1 >= 0)
                {
                    steps++;
                    position = Tuple.Create<int, int>(position.Item1, position.Item2 - 1);
                    return "You move West\n";
                }
                else { return "You bump into the wall\n"; }
            }
            // fires arrow in one of 4 directions
            else if (input.ToLower().Equals("f"))
            {
                if(haveArrow)
                {
                    haveArrow = false;
                    return " Would you like to fire North, East, South, or West? Input anything else to cancel\n";
                }
                else
                {
                    return "You have no arrow to fire\n";
                }
                
            }
            else if (input.ToLower().Equals("g"))
            {
                hasGold = true;
                switch (world[position.Item1, position.Item2])
                {
                    case 5:
                        world[position.Item1, position.Item2] = 0;
                        break;
                    case 7:
                        world[position.Item1, position.Item2] = 2;
                        break;
                    case 8:
                        world[position.Item1, position.Item2] = 4;
                        break;
                    case 9:
                        world[position.Item1, position.Item2] = 6;
                        break;
                    case 13:
                        world[position.Item1, position.Item2] = 12;
                        break;
                    default:
                        hasGold = false;
                        return "You touch the rough stone floor beneath your feet\n";
                }
                return "You picked up a mountain of gold!\n";
            }
            else if (input.ToLower().Equals("c"))
            {
                if (hasGold)
                {
                    return "You Have the Gold and have escaped! Congratulations, you win!\n";
                }
                else
                {
                    return "You can't possibly leave without the gold\n";
                }
            }
            else if (input.ToLower().Equals("help"))
            {
                return "You can move North (n), South (s), East (e), West (w), Fire the arrow (f), Grab gold (g), or Climb out (c). Type 'help' if you forget\n";
            }
            else
            {
                //input not recognized
                return "That input was not recognized, if you need help with commands type 'help'\n";
            }
        }
        public string fireArrowInput(string input)
        {
            if (input.ToLower().Equals("n"))
            {
                steps++;
                for (int i = position.Item1; i < maxXY; i++)
                {
                    switch (world[i, position.Item2])
                    {
                        case 3:
                            world[i, position.Item2] = 0;
                            wumpusKilled = true;
                            break;
                        case 11:
                            world[i, position.Item2] = 5;
                            wumpusKilled = true;
                            break;
                        case 12:
                            world[i, position.Item2] = 2;
                            wumpusKilled = true;
                            break;
                        case 13:
                            world[i, position.Item2] = 7;
                            wumpusKilled = true;
                            break;
                        default:
                            break;
                    }      
                }
                if (wumpusKilled)
                {
                    return "You hear a terrible scream echo through the cave\n";
                }
                else
                {
                    return "your arrow flies into the darkness and nothing happens\n";
                }
            }
            else if (input.ToLower().Equals("e"))
            {
                steps++;
                for (int i = position.Item2; i < maxXY; i++)
                {
                    switch (world[position.Item1, i])
                    {
                        case 3:
                            world[position.Item1, i] = 0;
                            wumpusKilled = true;
                            break;
                        case 11:
                            world[position.Item1, i] = 5;
                            wumpusKilled = true;
                            break;
                        case 12:
                            world[position.Item1, i] = 2;
                            wumpusKilled = true;
                            break;
                        case 13:
                            world[position.Item1, i] = 7;
                            wumpusKilled = true;
                            break;
                        default:
                            break;
                    }
                }
                if (wumpusKilled)
                {
                    return "You hear a terrible scream echo through the cave\n";
                }
                else
                {
                    return "your arrow flies into the darkness and nothing happens\n";
                }
            }
            else if (input.ToLower().Equals("s"))
            {
                steps++;
                for (int i = position.Item1; i >= 0; i--)
                {
                    switch (world[i, position.Item2])
                    {
                        case 3:
                            world[i, position.Item2] = 0;
                            wumpusKilled = true;
                            break;
                        case 11:
                            world[i, position.Item2] = 5;
                            wumpusKilled = true;
                            break;
                        case 12:
                            world[i, position.Item2] = 2;
                            wumpusKilled = true;
                            break;
                        case 13:
                            world[i, position.Item2] = 7;
                            wumpusKilled = true;
                            break;
                        default:
                            break;
                    }
                }
                if (wumpusKilled)
                {
                    return "You hear a terrible scream echo through the cave\n";
                }
                else
                {
                    return "your arrow flies into the darkness and nothing happens\n";
                }
            }
            else if (input.ToLower().Equals("w"))
            {
                steps++;
                for (int i = position.Item2; i >= 0; i--)
                {
                    switch (world[position.Item1, i])
                    {
                        case 3:
                            world[position.Item1, i] = 0;
                            wumpusKilled = true;
                            break;
                        case 11:
                            world[position.Item1, i] = 5;
                            wumpusKilled = true;
                            break;
                        case 12:
                            world[position.Item1, i] = 2;
                            wumpusKilled = true;
                            break;
                        case 13:
                            world[position.Item1, i] = 7;
                            wumpusKilled = true;
                            break;
                        default:
                            break;
                    }
                }
                if (wumpusKilled)
                {
                    return "You hear a terrible scream echo through the cave\n";
                }
                else
                {
                    return "your arrow flies into the darkness and nothing happens\n";
                }
            }
            else { haveArrow = true; return "Arrow canceled\n"; }
        }
        public int getScore()
        {
            return score-steps;
        }
    }
}
